<?php
define("SERVER",'localhost');

define("USER",'root');
define("PASS",'');
define("DBASE",'banaadir');
$conn = new mysqli(SERVER,USER,PASS,DBASE);
?>